import pandas as pd
import numpy as np
from arch import arch_model


def generate_risk_metrics(df, n_atr=14, n_vol=20):
    df_risk = df.copy()
    
    #ATR
    prev_close = df_risk['Close'].shift(1)
    tr1 = df_risk['High'] - df_risk['Low']
    tr2 = (df_risk['High'] - prev_close).abs()
    tr3 = (df_risk['Low'] - prev_close).abs()
    
    df_risk['TR'] = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    df_risk['ATR'] = df_risk['TR'].rolling(n_atr).mean()
    
    #VOLATILITY 
    # Thêm 1e-9 vào mẫu số hoặc log để tránh lỗi chia cho 0 nếu giá không đổi
    df_risk['Log_Return'] = np.log(df_risk['Close'] / df_risk['Close'].shift(1).replace(0, np.nan))
    df_risk['Vol_Daily'] = df_risk['Log_Return'].rolling(n_vol).std()
    df_risk['Vol_Annual'] = df_risk['Vol_Daily'] * np.sqrt(252)
    
    df_risk['ATR_Prev'] = df_risk['ATR'].shift(1)
    df_risk['Vol_Daily_Prev'] = df_risk['Vol_Daily'].shift(1)
    df_risk['Vol_Annual_Prev'] = df_risk['Vol_Annual'].shift(1)
    
    return df_risk

def full_generate_risk_metrics(df, n_atr=14, n_vol=20):
    """
    Áp dụng generate_risk_metrics cho từng mã cổ phiếu (Groupby).
    Tự động nhận diện xem Ticker nằm ở Index hay ở Cột để tránh KeyError.
    """
    
    # KIỂM TRA: Ticker nằm ở đâu?
    if 'Ticker' in df.index.names:
        # TRƯỜNG HỢP 1: Ticker là Index (Do stack tạo ra) -> Dùng level='Ticker'
        df_processed = df.groupby(level='Ticker', group_keys=False).apply(generate_risk_metrics, n_atr=n_atr, n_vol=n_vol)
        
    elif 'Ticker' in df.columns:
        # TRƯỜNG HỢP 2: Ticker là Cột bình thường -> Dùng by='Ticker'
        df_processed = df.groupby('Ticker', group_keys=False).apply(generate_risk_metrics, n_atr=n_atr, n_vol=n_vol)
        
    else:
        # Fallback: Nếu không tìm thấy Ticker, thử Reset Index rồi Groupby
        # (Đây là biện pháp an toàn cuối cùng)
        print("Không tìm thấy Index 'Ticker', đang thử Reset Index...")
        df_temp = df.reset_index()
        if 'Ticker' in df_temp.columns:
             df_processed = df_temp.groupby('Ticker', group_keys=False).apply(generate_risk_metrics, n_atr=n_atr, n_vol=n_vol)
             # Trả lại index cũ nếu cần, hoặc để nguyên
             if 'Date' in df_processed.columns:
                 df_processed = df_processed.set_index(['Date', 'Ticker'])
        else:
             raise KeyError("Dữ liệu đầu vào không có thông tin Ticker (cả ở Index lẫn Column).")

    return df_processed

#Position Sizing
def calculate_position_size(account_size, risk_pct, vol_annual, price, m=2.0):
    risk_amount = account_size * risk_pct
    vol_impact = (vol_annual * m * price) + 1e-9
    size = risk_amount / vol_impact
    return int(size)

#Hàm tính Stop Loss ban đầu
def calculate_initial_stop_loss(entry_price, method='sigma', vol_daily=None, atr=None, k_vol=2, k_atr=3, k_fixed=0.01, position_type=1):
    stop_loss_price = 0
    distance = 0
    
    if method == 'sigma':
        distance = k_vol * vol_daily
    elif method == 'atr':
        distance = k_atr * atr
    elif method == 'fixed_pct':
        distance = entry_price * k_fixed
  
    if position_type == 1:  # LONG
        stop_loss_price = entry_price - distance
    elif position_type == -1: # SHORT
        stop_loss_price = entry_price + distance
        
    return stop_loss_price

# 5. Hàm tính GARCH Volatility 
def get_garch_volatility(close_prices):
    try:
        returns = 100 * pd.Series(close_prices).pct_change().dropna()
        # Mô hình GARCH(1,1)
        model = arch_model(returns, vol='Garch', p=1, q=1, mean='Zero')
        res = model.fit(disp='off')
        vol = res.conditional_volatility

        # Ghép lại index cho khớp
        full_vol = pd.Series(index=pd.Series(close_prices).index, data=0.0)
        full_vol.loc[vol.index] = vol
        return full_vol / 100 # Trả về dạng thập phân (VD: 0.02)
    except:
        # Nếu lỗi (do dữ liệu quá ít), trả về mặc định 2%
        return pd.Series(0.02, index=close_prices.index)

#Hàm tính Ma trận Hiệp phương sai (QUAN TRỌNG CHO OPTIMIZER)
def calculate_covariance_matrix(df_prices, lookback_days=252):
    """
    Tính ma trận hiệp phương sai từ dữ liệu giá lịch sử.
    Input: DataFrame giá Close (Index=Date, Columns=Ticker - Wide Format)
    Output: Ma trận Covariance (N x N)
    """
    # 1. Tính lợi nhuận ngày
    returns = df_prices.pct_change().dropna()
    
    # 2. Lấy dữ liệu trong khung thời gian lookback gần nhất
    recent_returns = returns.tail(lookback_days)
    
    # 3. Tính ma trận Covariance (Annualized)
    # Nhân 252 để quy đổi ra rủi ro theo năm
    cov_matrix = recent_returns.cov() * 252
    
    return cov_matrix