import numpy as np
import pandas as pd
from scipy.optimize import minimize

class PortfolioOptimizer:
    """
    Dựa trên lý thuyết Mean-Variance Optimization (Markowitz).
    """

    def __init__(self, risk_aversion=2.0, max_weight=0.2):
        self.risk_aversion = risk_aversion
        self.max_weight = max_weight

    def optimize(self, expected_returns, covariance_matrix):
        """
        Giải bài toán tối ưu hóa:
        Maximize: w.T * mu - (lambda / 2) * w.T * Sigma * w
        Subject to: sum(w) = 1, 0 <= w <= max_weight
        """
        
        # 1. Chuẩn bị dữ liệu đầu vào
        # Chỉ lấy các mã có trong cả Expected Return và Covariance
        common_tickers = expected_returns.index.intersection(covariance_matrix.index)
        
        if len(common_tickers) == 0:
            return None
            
        mu = expected_returns.loc[common_tickers].values
        Sigma = covariance_matrix.loc[common_tickers, common_tickers].values
        tickers = common_tickers
        num_assets = len(mu)

        # 2. Hàm Mục Tiêu
        def objective_function(weights):
            portfolio_risk = np.dot(weights.T, np.dot(Sigma, weights))
            portfolio_return = np.dot(weights.T, mu)
            utility = portfolio_return - (self.risk_aversion / 2) * portfolio_risk
            return -utility # Minimize negative utility

        # 3. Ràng buộc
        constraints = [{'type': 'eq', 'fun': lambda w: np.sum(w) - 1}]
        bounds = tuple((0.0, self.max_weight) for _ in range(num_assets))

        # 4. Initial Guess
        initial_weights = np.array([1.0 / num_assets] * num_assets)

        try:
            result = minimize(
                objective_function, 
                initial_weights, 
                method='SLSQP', 
                bounds=bounds, 
                constraints=constraints,
                options={'disp': False}
            )
            
            if result.success:
                optimal_weights = pd.Series(result.x, index=tickers)
                optimal_weights[optimal_weights < 0.00001] = 0
                
                if optimal_weights.sum() > 0:
                    optimal_weights = optimal_weights / optimal_weights.sum()
                    
                return optimal_weights
            else:
                return None
                
        except Exception:
            return None

# --- Helper Function đã sửa ---
def convert_signal_to_expected_return(df_snapshot, df_volatility_snapshot):
    """
    Chuyển đổi Signal thành Expected Return.
    Input:
        df_snapshot: DataFrame chứa cột 'Signal' của 1 ngày cụ thể (Index = Ticker)
        df_volatility_snapshot: DataFrame chứa cột 'Vol_Annual' của 1 ngày cụ thể
    """
    
    # Đảm bảo index là Ticker
    if 'Ticker' in df_snapshot.columns:
        df_snapshot = df_snapshot.set_index('Ticker')
    
    if 'Ticker' in df_volatility_snapshot.columns:
        df_volatility_snapshot = df_volatility_snapshot.set_index('Ticker')

    # Join 2 bảng lại
    # Chỉ lấy những mã có Signal > 0 (Mua)
    # Những mã Signal <= 0 coi như không có kỳ vọng lợi nhuận -> Không đưa vào Optimizer
    
    # Lấy Signal
    if 'Signal' in df_snapshot.columns:
        signals = df_snapshot['Signal']
    else:
        # Trường hợp df_snapshot chính là Series Signal
        signals = df_snapshot
        
    # Lấy Volatility
    if 'Vol_Annual' in df_volatility_snapshot.columns:
        vols = df_volatility_snapshot['Vol_Annual']
    else:
        vols = df_volatility_snapshot
        
    # Tính Expected Return = Signal * Volatility
    # Chỉ giữ lại các mã có Signal > 0
    positive_signals = signals[signals > 0]
    
    # Khớp Volatility với các mã có Signal dương
    matched_vols = vols.reindex(positive_signals.index).fillna(0)
    
    # E(R)
    expected_returns = positive_signals * matched_vols
    
    return expected_returns