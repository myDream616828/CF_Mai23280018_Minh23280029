import pandas as pd
import numpy as np

# Import các module vệ tinh đã chuẩn bị
from stock_optimize import PortfolioOptimizer, convert_signal_to_expected_return
from stock_risk import calculate_covariance_matrix

class PortfolioEngine:
    def __init__(self, initial_capital=1_000_000_000, risk_aversion=2.5, max_weight=0.2):
        self.initial_capital = initial_capital
        
        # Khởi tạo bộ não tối ưu hóa (Optimizer)
        self.optimizer = PortfolioOptimizer(risk_aversion=risk_aversion, max_weight=max_weight)

    def _smooth_signals(self, df_strategy, span=3):
        """
        Kỹ thuật "Lưu hương" (Smoothing):
        Dùng EWM (Exponential Moving Average) để làm mượt tín hiệu.
        ĐÃ FIX LỖI ASSERTION ERROR (INDEX MISMATCH).
        """
        # Tạo bản sao để không ảnh hưởng dữ liệu gốc
        df = df_strategy.copy()
        
        # 1. Xử lý Index: Reset về dạng phẳng (Flat) để tránh lỗi MultiIndex 3 cấp
        is_multi_index = False
        if 'Ticker' in df.index.names:
            is_multi_index = True
            df = df.reset_index()
            
        # Đảm bảo có cột Ticker để group
        if 'Ticker' not in df.columns:
             if df.index.nlevels > 1:
                 df = df.reset_index()
        
        # 2. Tính toán EWM (Dùng transform để giữ nguyên kích thước index)
        if 'Signal' in df.columns:
            # Hàm lambda tính EWM
            df['Smoothed_Signal'] = df.groupby('Ticker')['Signal'].transform(
                lambda x: x.ewm(span=span, adjust=False).mean()
            )
        else:
            df['Smoothed_Signal'] = 0
            
        # 3. Khôi phục lại Index chuẩn (Date, Ticker)
        if is_multi_index and 'Date' in df.columns and 'Ticker' in df.columns:
            df = df.set_index(['Date', 'Ticker']).sort_index()
            
        return df

    def construct_portfolio(self, df_strategy, df_risk, prices_wide, rebalance_freq='M'):
        """
        Hàm chính: Xây dựng danh mục đầu tư theo thời gian.
        Input:
            df_strategy: DataFrame chứa Signal (từ stock_strategy).
            df_risk: DataFrame chứa Volatility (từ stock_risk).
            prices_wide: DataFrame giá Close dạng Wide (để tính Covariance).
            rebalance_freq: Tần suất tái cân bằng ('M', 'ME', 'Q', 'W').
        Output:
            df_target_weights: DataFrame tỷ trọng mục tiêu (Index=Date, Cols=Ticker).
        """
        print(f"   ⚙️ P6 Engine: Đang chạy tối ưu hóa danh mục ({rebalance_freq})...")
        
        # 1. Làm mượt tín hiệu
        df_final = self._smooth_signals(df_strategy)
        
        # 2. Xác định ngày Rebalance (FIX LỖI TYPE ERROR Ở ĐÂY)
        # Lấy danh sách ngày duy nhất
        unique_dates = df_final.index.get_level_values(0).unique().sort_values()
        
        # FIX: Tạo Series với Index là chính nó (DatetimeIndex) để resample được
        # Đồng thời xử lý warning 'M' -> 'ME' của Pandas mới
        freq_alias = rebalance_freq
        if freq_alias == 'M': freq_alias = 'ME' # Month End
        
        # QUAN TRỌNG: index=unique_dates để Pandas hiểu đây là Time Series
        ts_dates = pd.Series(unique_dates, index=unique_dates)
        rebalance_dates = ts_dates.resample(freq_alias).last().index
        
        # Warmup: Bỏ qua 1 năm đầu
        if len(unique_dates) > 0:
            # Tìm ngày cách ngày đầu tiên 365 ngày
            cutoff_date = unique_dates[0] + pd.Timedelta(days=365)
            # Lọc các ngày rebalance sau ngày cutoff
            valid_rebalance_dates = [d for d in rebalance_dates if d >= cutoff_date]
        else:
            valid_rebalance_dates = []
        
        target_weights_history = []
        
        # 3. Vòng lặp thời gian
        idx = pd.IndexSlice
        
        for i, current_date in enumerate(valid_rebalance_dates):
            # Fix lỗi ngày lễ: Tìm ngày trading gần nhất <= current_date
            if current_date not in unique_dates:
                # searchsorted trả về vị trí chèn để giữ thứ tự
                loc = unique_dates.searchsorted(current_date)
                if loc > 0:
                    current_date = unique_dates[loc - 1]
                else:
                    # Nếu ngày rebalance nhỏ hơn toàn bộ dữ liệu -> Bỏ qua
                    continue

            # a. Lấy Snapshot dữ liệu
            try:
                snapshot_strategy = df_final.loc[idx[current_date, :], :].reset_index(level=0, drop=True)
                
                if isinstance(df_risk.index, pd.MultiIndex):
                     snapshot_risk = df_risk.loc[idx[current_date, :], :].reset_index(level=0, drop=True)
                else:
                    snapshot_risk = df_risk[df_risk.index == current_date]

                historical_prices = prices_wide.loc[:current_date]
                
            except KeyError:
                continue

            # b. Lọc danh sách mã tiềm năng (Candidates)
            if 'Smoothed_Signal' in snapshot_strategy.columns:
                candidates = snapshot_strategy[snapshot_strategy['Smoothed_Signal'] > 0.1].index
            else:
                candidates = []
            
            if len(candidates) == 0:
                target_weights_history.append({'Date': current_date})
                continue
                
            # c. Chuẩn bị Input cho Optimizer
            valid_candidates = [c for c in candidates if c in historical_prices.columns]
            
            if len(valid_candidates) == 0:
                 target_weights_history.append({'Date': current_date})
                 continue

            cov_matrix = calculate_covariance_matrix(historical_prices[valid_candidates])
            
            snapshot_strategy_filtered = snapshot_strategy.loc[valid_candidates]
            snapshot_risk_filtered = snapshot_risk.loc[valid_candidates]
            
            temp_signal_df = pd.DataFrame({'Signal': snapshot_strategy_filtered['Smoothed_Signal']})
            temp_risk_df = pd.DataFrame({'Vol_Annual': snapshot_risk_filtered['Vol_Annual']})
            
            mu = convert_signal_to_expected_return(temp_signal_df, temp_risk_df)
            
            # d. CHẠY TỐI ƯU HÓA
            if mu is not None and cov_matrix is not None:
                optimal_weights = self.optimizer.optimize(mu, cov_matrix)
                
                if optimal_weights is not None:
                    row = optimal_weights.to_dict()
                    row['Date'] = current_date
                    target_weights_history.append(row)
                else:
                    target_weights_history.append({'Date': current_date})
            else:
                target_weights_history.append({'Date': current_date})

        # 4. Tổng hợp kết quả
        if not target_weights_history:
             print("   ⚠️ Warning: Không tạo được danh mục nào.")
             return pd.DataFrame()

        df_weights = pd.DataFrame(target_weights_history).set_index('Date').fillna(0)
        
        print(f"   ✅ P6 Engine: Đã xây dựng xong danh mục ({len(df_weights)} kỳ rebalance).")
        return df_weights

# ==============================================================================
# HÀM WRAPPER
# ==============================================================================
def run_allocation(df_strategy, df_risk, prices_wide):
    engine = PortfolioEngine()
    df_weights = engine.construct_portfolio(df_strategy, df_risk, prices_wide)
    return df_weights