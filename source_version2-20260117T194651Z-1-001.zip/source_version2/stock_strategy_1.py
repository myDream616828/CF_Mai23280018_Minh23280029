import pandas as pd
import numpy as np

# ==============================================================================
# 1. BASE CLASS (KHUNG SƯỜN CHUNG)
# ==============================================================================
class BaseStrategy:
    def __init__(self, name):
        self.name = name

    def calculate_score(self, df):
        """
        Input: DataFrame chứa các chỉ báo (Features)
        Output: Series điểm số (1: Mua, -1: Bán, 0: Giữ/Neutral)
        """
        raise NotImplementedError("Phải viết logic cho class con!")


class SniperStrategy(BaseStrategy):
    def __init__(self):
        super().__init__(name="Sniper")

    def calculate_score(self, df):
        # 1. Lấy dữ liệu (Đã tính ở stock_features)
        close = df['Close']
        sma_200 = df['SMA_200'].fillna(0)
        sma_50 = df['SMA_50'].fillna(0)
        vwma_50 = df['VWMA_50'].fillna(0)
        
        # 2. Logic Crossover (Viết lại logic của backtesting.lib bằng Pandas)
        # Cắt lên: Hôm nay VWMA > SMA nhưng hôm qua VWMA <= SMA
        cross_up = (vwma_50 > sma_50) & (vwma_50.shift(1) <= sma_50.shift(1))
        
        # Cắt xuống: Hôm nay VWMA < SMA nhưng hôm qua VWMA >= SMA
        cross_down = (vwma_50 < sma_50) & (vwma_50.shift(1) >= sma_50.shift(1))
        
        # 3. Logic Xu hướng (SMA 200)
        uptrend = close > sma_200
        downtrend = close < sma_200
        
        # 4. Xác định Tín hiệu
        score = pd.Series(0, index=df.index)
        
        # --- ENTRY LONG (MUA) ---
        # Logic: Giá > SMA200 (Up trend) VÀ VWMA cắt LÊN SMA50
        buy_signal = uptrend & cross_up
        
        # --- ENTRY SHORT / EXIT LONG (BÁN) ---
        # Logic: VWMA cắt XUỐNG SMA50
        sell_signal = cross_down | (downtrend & cross_down)
        
        # Gán điểm
        score[buy_signal] = 1   
        score[sell_signal] = -1 
        
        return score


class MeanReversionStrategy(BaseStrategy):
    def __init__(self):
        super().__init__(name="MeanReversion")

    def calculate_score(self, df):
        lower = df['Lower']
        upper = df['Upper']
        zscore = df['Zscore']
        pct_b = df['PercentB']
        
        score = pd.Series(0, index=df.index)
        
        # MUA: Giá thủng Band dưới HOẶC (Zscore thấp & %B thấp)
        buy_cond = (df['Close'] < lower) | ((zscore < -2) & (pct_b < 0))
        
        # BÁN: Giá vượt Band trên HOẶC (Zscore cao & %B cao)
        sell_cond = (df['Close'] > upper) | ((zscore > 2) & (pct_b > 1))
        
        score[buy_cond] = 1
        score[sell_cond] = -1
        
        return score


class MomentumStrategy(BaseStrategy):
    def __init__(self):
        super().__init__(name="Momentum")

    def calculate_score(self, df):
        sma_50 = df['SMA_50'].fillna(0)
        rsi = df['RSI'].fillna(50)
        
        score = pd.Series(0, index=df.index)
        
        buy_cond = (df['Close'] > sma_50) & (rsi > 50)
        sell_cond = (df['Close'] < sma_50)
        
        score[buy_cond] = 1
        score[sell_cond] = -1
        
        return score


class StrategyManager:
    def __init__(self):
        self.strategies = [
            SniperStrategy(),
            MeanReversionStrategy(),
            MomentumStrategy()
        ]
        self.weights = {
            "Sniper": 0.4,
            "MeanReversion": 0.3,
            "Momentum": 0.3
        }

    def apply_strategies(self, df_in):
        df = df_in.copy()
        total_weighted_score = 0
        
        for strategy in self.strategies:
            score_series = strategy.calculate_score(df)
            df[f"Score_{strategy.name}"] = score_series
            w = self.weights.get(strategy.name, 0)
            total_weighted_score += score_series * w
            
        df['Total_Score'] = total_weighted_score
        
        df['Signal'] = 0
        df.loc[df['Total_Score'] > 0.3, 'Signal'] = 1
        df.loc[df['Total_Score'] < -0.3, 'Signal'] = -1
        
        return df


def full_generate_strategy_signal(df):
    manager = StrategyManager()
    df_processed = df.groupby('Ticker', group_keys=False).apply(manager.apply_strategies)
    return df_processed