import pandas as pd
import numpy as np
import warnings
import os
from stock_load import load_local_data, download_data, TICKERS_70, START_DATE, END_DATE
from stock_preparation import clean_missing_values 
from stock_features import full_generate_features 
from stock_risk import full_generate_risk_metrics 
from stock_strategy_1 import full_generate_strategy_signal 
from stock_portfolio import PortfolioEngine
from stock_backtest_all import BacktestEngine


from stock_performance import (
    calculate_full_portfolio_performance, 
    full_get_trade_performance_metrics, 
    print_performance_report, 
    plot_performance
)

def run_system_pipeline(rebalance_freq='M', initial_capital=1_000_000_000):
    print("\n" + "="*60)
    print("FULL PIPELINE")
    print(f" Vốn khởi đầu: {initial_capital:,.0f} VND")
    print(f" Tần suất đảo danh mục: {rebalance_freq}")
    print("="*60)

    print("\n Đang load dữ liệu")
    df = load_local_data()
    if df is None:
        print("Không tìm thấy data offline. Đang tải mới từ Yahoo Finance...")
        df = download_data(TICKERS_70, START_DATE, END_DATE)
    
    print("Đang làm sạch dữ liệu...")
    df_clean = clean_missing_values(df) # (Đã bỏ winsorize để tránh sai số giá)
    print(f"Dữ liệu sẵn sàng: {df_clean.shape[0]} dòng.")

    # --------------------------------------------------------------------------
    # BƯỚC 2: TÍNH TOÁN (ENGINEERING)
    # --------------------------------------------------------------------------
    print("\n Đang tính toán....")
    
    # 2.1 Tính Features (RSI, Bollinger, SMA, VWMA...)
    print(" \nĐang tính toán các indicators")
    df_features = full_generate_features(df_clean)
    
    # 2.2 Tính Risk (Volatility Annual)
    print("\n Đang đo lường rủi ro (Volatility)...")
    df_risk = full_generate_risk_metrics(df_features)
    
    # 2.3 Chấm điểm Strategy (Sniper + MeanRev + Momentum)
    print(" \nĐang chạy các chiến lược (Strategy Scoring)...")
    df_signals = full_generate_strategy_signal(df_risk)
    
    print("\nĐã sinh tín hiệu Mua/Bán thành công.")

    # --------------------------------------------------------------------------
    # BƯỚC 3: XÂY DỰNG DANH MỤC (P6 - PORTFOLIO OPTIMIZATION)
    # --------------------------------------------------------------------------
    print(f"\n Tối ưu hóa Portfolio")
    
    # Chuẩn bị giá Close dạng Wide để tính Covariance Matrix bên trong P6
    prices_wide = df_signals['Close'].unstack()
    
    # Khởi tạo Engine P6 (Risk Aversion = 2.5, Max Weight = 20%)
    p6_engine = PortfolioEngine(risk_aversion=2.5, max_weight=0.2)
    
    # Chạy tối ưu hóa để ra Tỷ trọng mục tiêu (Target Weights)
    df_target_weights = p6_engine.construct_portfolio(df_signals, df_risk, prices_wide, rebalance_freq=rebalance_freq)
    
    # Lưu file weights để kiểm tra
    df_target_weights.to_csv('p6_target_weights.csv')
    print("Đã lưu tỷ trọng mục tiêu: target_weights.csv")

    # --------------------------------------------------------------------------
    # BƯỚC 4: MÔ PHỎNG GIAO DỊCH (P7 - BACKTEST EXECUTION)
    # --------------------------------------------------------------------------
    print("\n Backtest.....")
    
    # Chuẩn bị giá Open và Close dạng Wide cho P7 khớp lệnh
    prices_open_wide = df_signals['Open'].unstack()
    prices_close_wide = df_signals['Close'].unstack()
    
    # Phí 0.15%, Phí quản lý 2%/năm, Cap turnover 20%
    p7_engine = BacktestEngine(
        initial_capital=initial_capital,
        transaction_cost_pct=0.0015,
        expense_ratio_annual=0.02,
        turnover_cap=0.2
    )
    
    # Chạy mô phỏng
    df_nav, df_trades = p7_engine.run_backtest(prices_open_wide, prices_close_wide, df_target_weights)
    
    # Lưu log
    df_nav.to_csv('p7_nav_log.csv', index=False)
    df_trades.to_csv('p7_trade_log.csv', index=False)
    print(" Đã lưu log giao dịch: p7_nav_log.csv, p7_trade_log.csv")

   
    print("\nTỔNG HỢP BÁO CÁO HIỆU SUẤT...")
    
    if df_nav.empty:
        print(" Lỗi: Không có dữ liệu NAV để báo cáo.")
        return

    # 1. Tính chỉ số Portfolio Tổng (NAV Based)
    port_metrics = calculate_full_portfolio_performance(df_nav)
    
    # 2. In báo cáo đẹp ra màn hình
    print_performance_report(port_metrics)
    
    # 3. Vẽ biểu đồ
    plot_performance(df_nav, filename='final_performance_chart.png')
    
    # --------------------------------------------------------------------------
    # BƯỚC 6: PHÂN TÍCH CHI TIẾT LỆNH (TRADE ANALYSIS)
    # --------------------------------------------------------------------------
    print("\nPHÂN TÍCH CHI TIẾT TỪNG MÃ (TRADE METRICS)...")
    
    # Tính hiệu suất từng mã (Hit rate, Win/Loss, v.v.)
    total_test_days = len(df_nav)
    df_trade_metrics = full_get_trade_performance_metrics(df_trades, total_test_days)
    
    if not df_trade_metrics.empty:
        # Lưu file excel/csv để mom soi
        df_trade_metrics.to_csv('detailed_trade_metrics.csv', index=False)
        print(" Đã lưu phân tích chi tiết: detailed_trade_metrics.csv")
        
        # In Top 5 mã gánh team
        print("\nTOP 5 MÃ HIỆU QUẢ NHẤT (NET PROFIT):")
        print(df_trade_metrics[['Ticker', '5. Number of Trades', '7. Hit Rate', '3. Net Profit']].head(5).to_string(index=False))
    else:
        print(" Không có giao dịch nào được thực hiện.")

    print("\n" + "="*60)
    print("HOÀN TẤT TOÀN BỘ QUY TRÌNH. CHÚC MỪNG MOM!")
    print("="*60)

# ==============================================================================
# ENTRY POINT
# ==============================================================================
if __name__ == "__main__":
    # Mom có thể đổi 'M' (Tháng), 'Q' (Quý), 'W' (Tuần) tùy ý
    run_system_pipeline(rebalance_freq='M', initial_capital=1_000_000_000)