import pandas as pd
import numpy as np

# ==============================================================================
# 1. HELPER: XỬ LÝ KHỚP LỆNH (FIFO LOGIC)
# ==============================================================================
def _process_fifo_trades(df_trades_log):
    """
    Hàm phụ trợ: Chuyển đổi Nhật ký giao dịch (P7 Log) thành Danh sách các lệnh đã đóng.
    Dùng nguyên tắc FIFO (Vào trước ra trước) để khớp Mua và Bán.
    """
    if df_trades_log.empty:
        return []

    # Đảm bảo sort theo ngày
    df = df_trades_log.sort_values('Date')
    
    closed_trades = []
    # Queue lưu các lệnh mua: mỗi phần tử là [Date, Price, Shares]
    buy_queue = [] 

    for _, row in df.iterrows():
        action = row['Action']
        price = row['Price']
        shares = row['Shares']
        date = row['Date']
        
        if action == 'BUY':
            buy_queue.append({'Date': date, 'Price': price, 'Shares': shares})
            
        elif action == 'SELL':
            shares_to_sell = shares
            
            while shares_to_sell > 0 and buy_queue:
                # Lấy lệnh mua cũ nhất ra (FIFO)
                buy_order = buy_queue[0]
                
                matched_shares = min(shares_to_sell, buy_order['Shares'])
                
                # Tính toán PnL cho phần khớp này
                entry_price = buy_order['Price']
                exit_price = price
                pnl = (exit_price - entry_price) * matched_shares
                return_pct = (exit_price - entry_price) / entry_price
                
                # Tính thời gian giữ lệnh (Bars = Số ngày)
                duration = (date - buy_order['Date']).days
                
                closed_trades.append({
                    'pnl': pnl,
                    'return': return_pct,
                    'bars': duration if duration > 0 else 1, # Tối thiểu 1 ngày
                    'EntryDate': buy_order['Date'],
                    'ExitDate': date
                })
                
                # Cập nhật số lượng còn lại
                shares_to_sell -= matched_shares
                buy_order['Shares'] -= matched_shares
                
                # Nếu lệnh mua này đã khớp hết thì xóa khỏi hàng đợi
                if buy_order['Shares'] <= 0:
                    buy_queue.pop(0)

    return closed_trades

# ==============================================================================
# 2. CÁC HÀM TÍNH TOÁN (CORE METRICS)
# ==============================================================================

def calculate_trade_metrics(trade_log, total_bars=252):
    df = pd.DataFrame(trade_log)
    
    if df.empty:
        return {"Status": "Không có giao dịch nào"}
        
    winning_trades = df[df['pnl'] > 0]
    losing_trades = df[df['pnl'] <= 0]
    
    n_win = len(winning_trades)
    n_loss = len(losing_trades)
    n_total = n_win + n_loss
    
    gross_gain = winning_trades['pnl'].sum()
    gross_loss = losing_trades['pnl'].abs().sum()
    net_profit = gross_gain - gross_loss
    
    total_days_in_market = df['bars'].sum()
    time_in_market = total_days_in_market / total_bars
    
    number_of_trades = n_total
    years = total_bars / 365.25
    annual_turnover = n_total / years if years > 0 else n_total
    
    hit_rate = n_win / n_total if n_total > 0 else 0
    profit_factor = gross_gain / gross_loss if gross_loss != 0 else np.inf
    
    avg_gain = winning_trades['return'].mean() if n_win > 0 else 0
    avg_loss = abs(losing_trades['return'].mean()) if n_loss > 0 else 0
    slugging_ratio = avg_gain / avg_loss if avg_loss != 0 else np.inf

    metrics = {
        "1. Gross Gain": gross_gain,
        "2. Gross Loss": gross_loss,
        "3. Net Profit": net_profit,
        "4. % Time in Market": time_in_market,
        "5. Number of Trades": number_of_trades,
        "6. Annual Turnover": round(annual_turnover, 2),
        "7. Hit Rate": f"{hit_rate:.2%}",
        "8. Profit Factor": round(profit_factor, 2),
        "9. Avg Gain (Wins)": f"{avg_gain:.2%}",
        "10. Avg Loss (Losses)": f"{avg_loss:.2%}",
        "11. Slugging Ratio": round(slugging_ratio, 2)
    }
    
    return metrics

def get_trade_performance_metrics(ticker_df_trades, total_test_bars):
    closed_trades_list = _process_fifo_trades(ticker_df_trades)
    metrics = calculate_trade_metrics(closed_trades_list, total_bars=total_test_bars)
    return metrics

def full_get_trade_performance_metrics(df_trades_all, total_test_days):
    detailed_rows = []
    if df_trades_all.empty: return pd.DataFrame()

    tickers = df_trades_all['Ticker'].unique()
    for ticker in tickers:
        ticker_trades = df_trades_all[df_trades_all['Ticker'] == ticker].copy()
        m = get_trade_performance_metrics(ticker_trades, total_test_days)
        if isinstance(m, dict) and "Status" not in m:
            m['Ticker'] = ticker
            detailed_rows.append(m)
            
    df = pd.DataFrame(detailed_rows)
    if not df.empty and '3. Net Profit' in df.columns:
        df = df.sort_values(by="3. Net Profit", ascending=False)
        cols = ['Ticker'] + [c for c in df.columns if c != 'Ticker']
        return df[cols].reset_index(drop=True)
    return df

def calculate_full_portfolio_performance(df_nav):
    if df_nav.empty: return {}
    
    df = df_nav.copy()
    if 'Date' in df.columns: df = df.set_index('Date')
    
    nav = df['NAV']
    r = nav.pct_change().fillna(0)
    T = len(r)
    
    avg_daily_return = r.mean()
    annual_avg_return = avg_daily_return * 252
    
    cum_prod = nav.iloc[-1] / nav.iloc[0]
    days = (df.index[-1] - df.index[0]).days
    annual_geo_return = (cum_prod ** (365.25 / days)) - 1 if days > 0 else 0
    
    daily_vol = r.std()
    annual_vol = daily_vol * np.sqrt(252)
    
    cum_equity = nav
    peak = cum_equity.cummax()
    max_dd = ((cum_equity - peak) / peak).min()

    up_days = r[r > 0]
    down_days = r[r < 0]
    hit_rate = len(up_days) / T
    gross_profit = up_days.sum()
    gross_loss = abs(down_days.sum())
    
    metrics = {
        "total_test_bars": T,
        "avg_daily_return": avg_daily_return,
        "annual_avg_return": annual_avg_return,
        "annual_geo_return": annual_geo_return,
        "daily_vol": daily_vol,
        "annual_vol": annual_vol,
        "max_drawdown": max_dd,
        "sharpe_ratio": annual_avg_return / annual_vol if annual_vol != 0 else 0,
        "calmar_ratio": annual_avg_return / abs(max_dd) if max_dd != 0 else 0,
        "hit_rate": hit_rate,
        "profit_factor": gross_profit / gross_loss if gross_loss != 0 else 0,
        "long_cum_return": cum_prod - 1,
        "ending_capital": nav.iloc[-1]
    }
    return metrics

# ==============================================================================
# 3. CÁC HÀM HIỂN THỊ (SAFE PLOTTING)
# ==============================================================================

def print_performance_report(metrics):
    if not metrics:
        print("Không có dữ liệu hiệu suất.")
        return

    print("\n" + "="*50)
    print("📊 BÁO CÁO HIỆU SUẤT (P7 BACKTEST)")
    print("="*50)
    
    print(f"💰 TÀI CHÍNH")
    print(f"   • Vốn cuối cùng   : {metrics.get('ending_capital', 0):,.0f} VND")
    print(f"   • Tổng lợi nhuận  : {metrics.get('long_cum_return', 0):.2%}")
    print(f"   • CAGR (Geo Ret)  : {metrics.get('annual_geo_return', 0):.2%}")
    
    print("-" * 50)
    print(f"📉 RỦI RO")
    print(f"   • Max Drawdown    : {metrics.get('max_drawdown', 0):.2%}")
    print(f"   • Volatility (Năm): {metrics.get('annual_vol', 0):.2%}")
    print(f"   • Sharpe Ratio    : {metrics.get('sharpe_ratio', 0):.2f}")
    
    print("-" * 50)
    print(f"⚙️ THỐNG KÊ")
    print(f"   • Profit Factor   : {metrics.get('profit_factor', 0):.2f}")
    print(f"   • Hit Rate (Ngày) : {metrics.get('hit_rate', 0):.2%}")
    print("="*50 + "\n")

def plot_performance(df_nav, filename='backtest_result.png'):
    """
    Hàm vẽ biểu đồ NAV.
    Sử dụng import cục bộ để tránh lỗi 'module object is not callable'.
    """
    if df_nav.empty: return
    
    # IMPORT CỤC BỘ (An toàn tuyệt đối)
    import matplotlib.pyplot as plt 
    
    df = df_nav.copy()
    if 'Date' in df.columns:
        df = df.set_index('Date')
        
    plt.figure(figsize=(12, 6))
    
    # Vẽ đường NAV
    plt.plot(df.index, df['NAV'], label='Portfolio NAV', color='#1f77b4', linewidth=1.5)
    
    # Vẽ Drawdown (Fill vùng màu đỏ)
    rolling_max = df['NAV'].cummax()
    dd = (df['NAV'] - rolling_max) / rolling_max
    
    # Fill màu đỏ nhạt cho vùng drawdown
    plt.fill_between(df.index, dd * df['NAV'].max() + df['NAV'].min(), df['NAV'].min(), 
                     color='red', alpha=0.1, label='Drawdown Risk')
    
    plt.title('Performance Chart: NAV & Drawdown')
    plt.xlabel('Thời gian')
    plt.ylabel('Giá trị tài sản (VND)')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    
    plt.tight_layout()
    plt.savefig(filename)
    plt.close() # Đóng figure để giải phóng bộ nhớ
    print(f"   📷 Đã lưu biểu đồ: {filename}")