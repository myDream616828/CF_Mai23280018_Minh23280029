import pandas as pd
import numpy as np

class BacktestEngine:
    def __init__(self, initial_capital=1_000_000_000, 
                 transaction_cost_pct=0.0015,  # 0.15% (Phí + Thuế)
                 expense_ratio_annual=0.02,    # 2% phí quản lý/năm
                 turnover_cap=0.2):            # Giới hạn xoay vòng 20% NAV/lần
        
        self.initial_capital = initial_capital
        self.transaction_cost_pct = transaction_cost_pct
        self.expense_daily = expense_ratio_annual / 252.0
        self.turnover_cap = turnover_cap
        
        # --- STATE VARIABLES (TRẠNG THÁI TÀI KHOẢN) ---
        self.current_cash = initial_capital
        self.current_holdings = {} # {Ticker: Shares}
        
        # --- LOGGING ---
        self.nav_log = []   # Ghi nhận NAV hàng ngày
        self.trade_log = [] # Ghi nhận từng lệnh mua bán

    def _get_portfolio_value(self, prices_dict, holdings, cash):
        """
        Tính NAV tại một thời điểm cụ thể.
        Input: 
            prices_dict: Dictionary {Ticker: Price}
            holdings: Dictionary {Ticker: Shares}
            cash: float
        """
        equity_value = 0
        for ticker, shares in holdings.items():
            if ticker in prices_dict and not np.isnan(prices_dict[ticker]):
                equity_value += shares * prices_dict[ticker]
        return cash + equity_value

    def _calculate_w_exec(self, w_prev, w_target, nav_pre):
        """
        MÔ HÌNH HÓA TURNOVER & CAP (Mục 2.2 c, d)
        Tính toán trọng số thực thi (w_exec) dựa trên Turnover Cap.
        """
        # Hợp nhất danh sách mã từ cả 2 danh mục
        all_tickers = set(w_prev.keys()) | set(w_target.keys())
        
        # 1. Tính Turnover Mục Tiêu (t_target)
        # Turnover = 0.5 * sum(|w_target - w_prev|)
        sum_abs_diff = 0
        diffs = {}
        
        for t in all_tickers:
            wp = w_prev.get(t, 0.0)
            wt = w_target.get(t, 0.0)
            diff = wt - wp
            diffs[t] = diff
            sum_abs_diff += abs(diff)
            
        turnover_target = 0.5 * sum_abs_diff
        
        # 2. Áp dụng Turnover Cap (apply turnover cap)
        # Nếu t_target > cap => scale lại
        scale_factor = 1.0
        is_capped = False
        
        if turnover_target > self.turnover_cap and turnover_target > 0:
            scale_factor = self.turnover_cap / turnover_target
            is_capped = True
            
        # 3. Tính w_exec (Trọng số thực thi)
        # w_exec = w_prev + scale * (w_target - w_prev)
        w_exec = {}
        turnover_executed = turnover_target * scale_factor
        
        for t in all_tickers:
            wp = w_prev.get(t, 0.0)
            diff = diffs[t]
            # Công thức toán học co kéo tỷ trọng
            w_exec[t] = wp + (diff * scale_factor)
            
        return w_exec, turnover_executed, is_capped

    def run_backtest(self, df_prices_open, df_prices_close, df_target_weights):
        """
        VÒNG LẶP BACKTEST THEO NGÀY
        Input:
            df_prices_open: DataFrame giá Open (Wide: Index=Date, Col=Ticker)
            df_prices_close: DataFrame giá Close (Wide: Index=Date, Col=Ticker)
            df_target_weights: DataFrame Weight mục tiêu từ P6 (Index=Date, Col=Ticker)
        """
        print(f"   ⚔️ P7 Simulation: Bắt đầu mô phỏng giao dịch...")
        
        # Lấy tập hợp tất cả các ngày trading (All dates)
        trading_days = df_prices_close.index.sort_values()
        # Lọc ngày bắt đầu từ khi có tín hiệu Weight đầu tiên
        start_date = df_target_weights.index[0]
        trading_days = trading_days[trading_days >= start_date]
        
        for current_date in trading_days:
            # Dữ liệu giá hôm nay (chuyển sang dict cho nhanh)
            # Fallback: Nếu thiếu Open thì dùng Close (hoặc logic fillna đã làm ở P1)
            try:
                # 2.1 NAV tại OPEN (Trước giao dịch)
                if current_date in df_prices_open.index:
                    prices_open = df_prices_open.loc[current_date].to_dict()
                else:
                    prices_open = df_prices_close.loc[current_date].to_dict()
                
                prices_close = df_prices_close.loc[current_date].to_dict()
            except KeyError:
                continue

            # Tính NAV Open Pre
            nav_open_pre = self._get_portfolio_value(prices_open, self.current_holdings, self.current_cash)
            
            # Khởi tạo biến log
            daily_turnover = 0
            daily_tx_cost = 0
            is_rebalance_day = False
            is_capped = False
            
            # 2.2 Nếu là ngày Rebalance -> Thực thi giao dịch tại OPEN
            if current_date in df_target_weights.index:
                is_rebalance_day = True
                
                # (a) Xác định trọng số hiện tại (w_prev)
                w_prev = {}
                if nav_open_pre > 0:
                    for t, s in self.current_holdings.items():
                        if t in prices_open:
                            val = s * prices_open[t]
                            w_prev[t] = val / nav_open_pre
                            
                # (b) Lấy trọng số mục tiêu (w_target)
                target_row = df_target_weights.loc[current_date]
                w_target = target_row[target_row > 0].to_dict() # Chỉ lấy mã có tỷ trọng > 0
                
                # (c) & (d) Tính Turnover Cap và w_exec
                w_exec, daily_turnover, is_capped = self._calculate_w_exec(w_prev, w_target, nav_open_pre)
                
                # (e) Tạo lệnh giao dịch: Target Value -> Delta Quantity
                sell_orders = []
                buy_orders = []
                
                # Duyệt qua tất cả các mã cần xử lý
                all_involved_tickers = set(self.current_holdings.keys()) | set(w_exec.keys())
                
                for t in all_involved_tickers:
                    # Lấy giá Open để khớp lệnh
                    price = prices_open.get(t, 0)
                    if price <= 0 or np.isnan(price): continue
                    
                    # Tính Target Value = NAV_Pre * w_exec
                    target_w = w_exec.get(t, 0.0)
                    target_val = nav_open_pre * target_w
                    
                    # Tính Current Value
                    current_shares = self.current_holdings.get(t, 0)
                    current_val = current_shares * price
                    
                    # Tính Delta Quantity
                    delta_val = target_val - current_val
                    delta_shares = int(delta_val / price)
                    
                    if delta_shares < 0:
                        sell_orders.append((t, abs(delta_shares), price))
                    elif delta_shares > 0:
                        buy_orders.append((t, delta_shares, price))
                        
                # (f) Thực thi lệnh: SELL trước, BUY sau
                
                # --- EXECUTE SELL ---
                for t, shares, price in sell_orders:
                    trade_val = shares * price
                    cost = trade_val * self.transaction_cost_pct
                    
                    # Cập nhật tiền và hàng
                    self.current_cash += (trade_val - cost) # Bán thu tiền về trừ phí
                    self.current_holdings[t] -= shares
                    if self.current_holdings[t] <= 0:
                        del self.current_holdings[t]
                        
                    daily_tx_cost += cost
                    
                    # Ghi Log
                    self.trade_log.append({
                        'Date': current_date, 'Ticker': t, 'Action': 'SELL',
                        'Price': price, 'Shares': shares, 'Value': trade_val, 'Cost': cost
                    })
                    
                # --- EXECUTE BUY ---
                for t, shares, price in buy_orders:
                    trade_val = shares * price
                    cost = trade_val * self.transaction_cost_pct
                    total_outflow = trade_val + cost
                    
                    # Kiểm tra đủ tiền không
                    if self.current_cash >= total_outflow:
                        self.current_cash -= total_outflow
                        self.current_holdings[t] = self.current_holdings.get(t, 0) + shares
                        
                        daily_tx_cost += cost
                        
                        # Ghi Log
                        self.trade_log.append({
                            'Date': current_date, 'Ticker': t, 'Action': 'BUY',
                            'Price': price, 'Shares': shares, 'Value': trade_val, 'Cost': cost
                        })
                    else:
                        # Logic phụ: Nếu không đủ tiền (do lệch giá/làm tròn), mua tối đa có thể
                        # (Có thể bỏ qua hoặc xử lý mua lẻ)
                        pass

            # 2.3 NAV cuối ngày tại CLOSE (Mark to Market)
            nav_close = self._get_portfolio_value(prices_close, self.current_holdings, self.current_cash)
            
            # 2.4 Khấu trừ Expense Ratio (Phí quản lý)
            # Phí trừ trực tiếp vào NAV (tức là giảm Cash hoặc giảm Equity ngầm định, ở đây ta giảm Cash)
            daily_fee_val = nav_close * self.expense_daily
            self.current_cash -= daily_fee_val
            
            # Cập nhật lại NAV Close Final sau phí
            nav_final = nav_close - daily_fee_val
            
            # Tính Drawdown tại thời điểm này
            # (Sẽ tính sau ở bước performance, nhưng lưu NAV để tính)
            
            # 2.5 Ghi Result Row
            self.nav_log.append({
                'Date': current_date,
                'NAV': nav_final,
                'Cash': self.current_cash,
                'Turnover': daily_turnover if is_rebalance_day else 0.0,
                'Tx_Cost': daily_tx_cost,
                'Fee_Mgmt': daily_fee_val,
                'Is_Rebalance': is_rebalance_day,
                'Is_Capped': is_capped
            })

        print(f"Simulation: Hoàn tất ({len(self.nav_log)} ngày giao dịch).")
        
        # 3. Tổng hợp bảng kết quả
        df_backtest_result = pd.DataFrame(self.nav_log)
        df_trade_log = pd.DataFrame(self.trade_log)
        
        return df_backtest_result, df_trade_log