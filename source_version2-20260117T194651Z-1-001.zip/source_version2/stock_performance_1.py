import pandas as pd
import numpy as np

def _process_fifo_trades(df_trades_log):
    """
    Hàm phụ trợ: Chuyển đổi Nhật ký giao dịch (P7 Log) thành Danh sách các lệnh đã đóng (Closed Trades).
    Dùng nguyên tắc FIFO (Vào trước ra trước) để khớp Mua và Bán.
    """
    if df_trades_log.empty:
        return []

    #Đảm bảo sort theo ngày
    df = df_trades_log.sort_values('Date')
    
    closed_trades = []
    #Queue lưu các lệnh mua: mỗi phần tử là [Date, Price, Shares]
    buy_queue = [] 

    for _, row in df.iterrows():
        action = row['Action']
        price = row['Price']
        shares = row['Shares']
        date = row['Date']
        
        if action == 'BUY':
            buy_queue.append({'Date': date, 'Price': price, 'Shares': shares})
            
        elif action == 'SELL':
            shares_to_sell = shares
            
            while shares_to_sell > 0 and buy_queue:
                # Lấy lệnh mua cũ nhất ra (FIFO)
                buy_order = buy_queue[0]
                
                matched_shares = min(shares_to_sell, buy_order['Shares'])
                
                # Tính toán PnL cho phần khớp này
                entry_price = buy_order['Price']
                exit_price = price
                pnl = (exit_price - entry_price) * matched_shares
                return_pct = (exit_price - entry_price) / entry_price
                
                # Tính thời gian giữ lệnh (Bars = Số ngày)
                duration = (date - buy_order['Date']).days
                
                closed_trades.append({
                    'pnl': pnl,
                    'return': return_pct,
                    'bars': duration if duration > 0 else 1, # Tối thiểu 1 ngày
                    'EntryDate': buy_order['Date'],
                    'ExitDate': date
                })
                
                # Cập nhật số lượng còn lại
                shares_to_sell -= matched_shares
                buy_order['Shares'] -= matched_shares
                
                # Nếu lệnh mua này đã khớp hết thì xóa khỏi hàng đợi
                if buy_order['Shares'] <= 0:
                    buy_queue.pop(0)

    return closed_trades

def calculate_trade_metrics(trade_log, total_bars=252):
    """
    Tính toán 11 chỉ số hiệu suất cấp độ Lệnh (Trade-Level).
    Giữ nguyên logic tính toán của mom.
    """
    df = pd.DataFrame(trade_log)
    
    if df.empty:
        return {"Status": "Không có giao dịch nào"}
        
    # Chuẩn bị 
    winning_trades = df[df['pnl'] > 0]
    losing_trades = df[df['pnl'] <= 0]
    
    n_win = len(winning_trades)
    n_loss = len(losing_trades)
    n_total = n_win + n_loss
    
    # Tính toán các metric 
    gross_gain = winning_trades['pnl'].sum()
    gross_loss = losing_trades['pnl'].abs().sum()
    net_profit = gross_gain - gross_loss
    
    # Total days in market (Cộng dồn số ngày giữ lệnh)
    total_days_in_market = df['bars'].sum()
    time_in_market = total_days_in_market / total_bars
    
    number_of_trades = n_total
    years = total_bars / 365.25 # Fix lại mẫu số cho đúng chuẩn năm
    annual_turnover = n_total / years if years > 0 else n_total
    
    hit_rate = n_win / n_total if n_total > 0 else 0
    profit_factor = gross_gain / gross_loss if gross_loss != 0 else np.inf
    
    avg_gain = winning_trades['return'].mean() if n_win > 0 else 0
    avg_loss = abs(losing_trades['return'].mean()) if n_loss > 0 else 0
    slugging_ratio = avg_gain / avg_loss if avg_loss != 0 else np.inf


    metrics = {
        "1. Gross Gain": gross_gain,
        "2. Gross Loss": gross_loss,
        "3. Net Profit": net_profit,
        "4. % Time in Market": time_in_market,
        "5. Number of Trades": number_of_trades,
        "6. Annual Turnover": round(annual_turnover, 2),
        "7. Hit Rate": f"{hit_rate:.2%}",
        "8. Profit Factor": round(profit_factor, 2),
        "9. Avg Gain (Wins)": f"{avg_gain:.2%}",
        "10. Avg Loss (Losses)": f"{avg_loss:.2%}",
        "11. Slugging Ratio": round(slugging_ratio, 2)
    }
    
    return metrics

def get_trade_performance_metrics(ticker_df_trades, total_test_bars):
    """
    Hàm này nhận DataFrame các lệnh của 1 Ticker cụ thể,
    Chuyển qua logic FIFO để tính Entry/Exit, rồi ném vào calculate_trade_metrics.
    """
    #Chuyển nhật ký Mua/Bán thành các Lệnh đã đóng (Matched Trades)
    closed_trades_list = _process_fifo_trades(ticker_df_trades)
    
    #Tính toán chỉ số
    metrics = calculate_trade_metrics(closed_trades_list, total_bars=total_test_bars)
    
    return metrics

def full_get_trade_performance_metrics(df_trades_all, total_test_days):
    """
    Duyệt qua từng Ticker trong file log tổng của P7 để tính metrics chi tiết.
    """
    detailed_rows = []
    
    if df_trades_all.empty:
        return pd.DataFrame()

    # Lấy danh sách các mã có giao dịch
    tickers = df_trades_all['Ticker'].unique()
    
    for ticker in tickers:
        # Lọc trade của mã này
        ticker_trades = df_trades_all[df_trades_all['Ticker'] == ticker].copy()
        
        # Gọi hàm tính toán
        m = get_trade_performance_metrics(ticker_trades, total_test_days)
        
        # Gắn Ticker vào
        if isinstance(m, dict) and "Status" not in m:
            m['Ticker'] = ticker
            detailed_rows.append(m)
            
    df = pd.DataFrame(detailed_rows)
    
    # Sắp xếp và Reorder columns y như mom muốn
    if not df.empty and '3. Net Profit' in df.columns:
        df = df.sort_values(by="3. Net Profit", ascending=False)
        cols = ['Ticker'] + [c for c in df.columns if c != 'Ticker']
        return df[cols].reset_index(drop=True)
    
    return df

def calculate_full_portfolio_performance(df_nav):
    """
    Tính toán chỉ số Portfolio tổng (dựa trên NAV).
    """
    if df_nav.empty: return {}
    
    # Chuẩn bị dữ liệu
    df = df_nav.copy()
    if 'Date' in df.columns:
        df = df.set_index('Date')
    
    # Tính Returns
    nav = df['NAV']
    r = nav.pct_change().fillna(0) # Daily Return series
    T = len(r) # Total bars
    
    # 2. Tính toán các chỉ số (Logic Portfolio chuẩn)
    avg_daily_return = r.mean()
    annual_avg_return = avg_daily_return * 252
    
    # Geometric Return (Lãi kép thực tế)
    total_ret = (nav.iloc[-1] / nav.iloc[0]) - 1
    cum_prod = nav.iloc[-1] / nav.iloc[0]
    days = (df.index[-1] - df.index[0]).days
    annual_geo_return = (cum_prod ** (365.25 / days)) - 1 if days > 0 else 0
    
    daily_vol = r.std()
    annual_vol = daily_vol * np.sqrt(252)
    
    # Max Drawdown
    cum_equity = nav
    peak = cum_equity.cummax()
    max_dd = ((cum_equity - peak) / peak).min()

    # Thống kê lệnh (Tính trên NAV thay vì từng lệnh)
    up_days = r[r > 0]
    down_days = r[r < 0]
    hit_rate = len(up_days) / T # % số ngày xanh
    
    gross_profit = up_days.sum()
    gross_loss = abs(down_days.sum())
    
    metrics = {
        "total_test_bars": T,
        "avg_daily_return": avg_daily_return,
        "annual_avg_return": annual_avg_return,
        "annual_geo_return": annual_geo_return,
        "daily_vol": daily_vol,
        "annual_vol": annual_vol,
        "max_drawdown": max_dd,
        "sharpe_ratio": annual_avg_return / annual_vol if annual_vol != 0 else 0,
        "calmar_ratio": annual_avg_return / abs(max_dd) if max_dd != 0 else 0,
        "hit_rate": hit_rate, # Lưu ý: Đây là % ngày thắng của Portfolio
        "profit_factor": gross_profit / gross_loss if gross_loss != 0 else 0,
        "long_cum_return": total_ret
    }
    
    return metrics