import pandas as pd
import pandas_ta as ta
import numpy as np

# ==============================================================================
# 1. CÁC HÀM TÍNH TOÁN CƠ BẢN (GIỮ NGUYÊN)
# ==============================================================================

def generate_bollinger_band_indicator(df_in, N=20, K=2):
    df_out = df_in.copy()
    price = df_out['Close']
    votatility = price.rolling(N).std()
    
    df_out["Middle"] = price.rolling(N).mean()
    df_out["Upper"] = df_out["Middle"] + K * votatility
    df_out["Lower"] = df_out["Middle"] - K * votatility
    
    votatility = votatility.replace(0, np.nan)
    df_out["Zscore"] = (price - df_out["Middle"]) / votatility
    
    range_bb = df_out["Upper"] - df_out["Lower"]
    range_bb = range_bb.replace(0, np.nan)
    df_out["PercentB"] = (price - df_out["Lower"]) / range_bb
    return df_out 

def generate_channel_breakout_indicator(df, n_entry=20, m_exit=10):
    df = df.copy()
    df['Upper_Entry'] = df['High'].rolling(n_entry).max().shift(1)
    df['Lower_Entry'] = df['Low'].rolling(n_entry).min().shift(1)
    df['Upper_Exit'] = df['High'].rolling(m_exit).max().shift(1)
    df['Lower_Exit'] = df['Low'].rolling(m_exit).min().shift(1)
    return df

def get_vwma(close, volume, length):
    return ta.vwma(pd.Series(close), pd.Series(volume), length=length)

def get_sma(close, length):
    return ta.sma(pd.Series(close), length=length)

# ==============================================================================
# 2. PHẦN BỔ SUNG & TỔNG HỢP
# ==============================================================================

def generate_additional_features(df):
    df = df.copy()
    
    # 1. RSI
    df['RSI'] = ta.rsi(df['Close'], length=14)
    
    # 2. Volume Spike
    df['Vol_MA20'] = df['Volume'].rolling(20).mean()
    df['Vol_Spike'] = np.where(df['Volume'] > 1.5 * df['Vol_MA20'], 1, 0)
    
    # 3. Các đường MA cho Sniper
    df['SMA_200'] = ta.sma(df['Close'], length=200)
    df['SMA_50'] = ta.sma(df['Close'], length=50)
    df['VWMA_50'] = ta.vwma(df['Close'], df['Volume'], length=50)
    
    # 4. Alias
    if 'Upper_Entry' in df.columns:
        df['High_20'] = df['Upper_Entry']
        
    return df

def generate_all_indicators(df):
    """Worker function: Chạy trên từng mã riêng lẻ"""
    df = generate_bollinger_band_indicator(df)
    df = generate_channel_breakout_indicator(df)
    df = generate_additional_features(df)
    return df

# ==============================================================================
# 3. HÀM CHÍNH (ĐÃ SỬA CÁCH GROUPBY ĐỂ TRÁNH LỖI MẤT TICKER)
# ==============================================================================

def full_generate_features(df):
    """
    Hàm này thay thế cho full_generate_bollinger... cũ.
    Đã FIX lỗi FutureWarning và KeyError bằng cách dùng group_keys=True.
    """
    df_in = df.copy()
    
    # BƯỚC 1: Chuẩn hóa Input
    # Đưa Ticker ra cột, đưa Date vào Index (để các hàm rolling tính đúng theo thời gian)
    if 'Ticker' in df_in.index.names:
        df_in = df_in.reset_index()
        
    if 'Date' in df_in.columns:
        df_in = df_in.set_index('Date')
    
    if 'Ticker' not in df_in.columns:
         # Nếu reset index rồi mà vẫn ko có Ticker thì bó tay
         if df_in.index.name == 'Ticker':
             df_in = df_in.reset_index()
         else:
             raise KeyError("Dữ liệu đầu vào thiếu cột Ticker!")

    # BƯỚC 2: Groupby và Apply
    # KEY FIX: Dùng group_keys=True. 
    # Nó sẽ tạo ra Index dạng MultiIndex (Ticker, Date) -> Đảm bảo không bao giờ mất Ticker.
    try:
        # Thử với syntax mới (Pandas > 2.0) để tắt warning
        df_processed = df_in.groupby('Ticker', group_keys=True).apply(generate_all_indicators, include_groups=False)
    except TypeError:
        # Fallback cho Pandas cũ
        df_processed = df_in.groupby('Ticker', group_keys=True).apply(generate_all_indicators)
    
    # BƯỚC 3: Xử lý Output
    # Lúc này Index đang là (Ticker, Date). Ta cần reset lại cho sạch.
    df_processed = df_processed.reset_index()
    
    # Loại bỏ cột Ticker thừa nếu nó bị duplicate (level_1, Ticker, etc.)
    # Chỉ giữ lại 1 cột Ticker và 1 cột Date chuẩn
    
    # Đảm bảo set đúng Index chuẩn (Date, Ticker) cho các file sau dùng
    if 'Date' in df_processed.columns and 'Ticker' in df_processed.columns:
        df_processed = df_processed.set_index(['Date', 'Ticker']).sort_index()
    elif 'level_1' in df_processed.columns: # Trường hợp Pandas cũ đặt tên index phụ là level_1
        df_processed = df_processed.rename(columns={'level_1': 'Date'})
        df_processed = df_processed.set_index(['Date', 'Ticker']).sort_index()

    return df_processed