import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
import os

# Suppress warnings
warnings.filterwarnings("ignore")

# --- IMPORT MODULES ---
from stock_load import load_local_data, download_data, TICKERS_70, START_DATE, END_DATE
from stock_preparation import clean_missing_values
# Import the NEW features and strategy modules you updated
from stock_features import full_generate_features 
from stock_strategy import full_generate_strategy_signal
from stock_risk import full_generate_risk_metrics, calculate_covariance_matrix
from stock_optimizer import PortfolioOptimizer

# ==============================================================================
# INTERNAL REPORTING FUNCTION (ENGLISH)
# ==============================================================================
def print_internal_report(df_result, initial_capital):
    """Calculates and prints a detailed performance report in English."""
    nav = df_result['NAV']
    returns = df_result['Return']
    
    # 1. Calculate Returns
    ending_capital = nav.iloc[-1]
    net_profit = ending_capital - initial_capital
    total_return = (ending_capital / initial_capital) - 1
    
    # CAGR (Compound Annual Growth Rate)
    days = (nav.index[-1] - nav.index[0]).days
    cagr = (ending_capital / initial_capital) ** (365.25 / days) - 1 if days > 0 else 0
    
    # 2. Calculate Risk
    volatility = returns.std() * np.sqrt(252) # Annualized
    
    # Sharpe Ratio (assuming risk-free rate = 0)
    sharpe_ratio = (returns.mean() * 252) / volatility if volatility != 0 else 0
    
    # Sortino Ratio (Downside risk only)
    neg_ret = returns[returns < 0]
    downside_dev = neg_ret.std() * np.sqrt(252)
    sortino_ratio = (returns.mean() * 252) / downside_dev if downside_dev != 0 else 0
    
    # 3. Max Drawdown
    rolling_max = nav.cummax()
    drawdown = (nav - rolling_max) / rolling_max
    max_drawdown = drawdown.min()
    max_dd_date = drawdown.idxmin()
    
    # 4. Win Rate
    wins = len(returns[returns > 0])
    losses = len(returns[returns < 0])
    win_rate = wins / (wins + losses) if (wins + losses) > 0 else 0

    # PRINT REPORT
    print("\n" + "="*50)
    print("📊 DETAILED PORTFOLIO PERFORMANCE REPORT")
    print("="*50)
    print(f"💰 CAPITAL & RETURNS")
    print(f"   • Initial Capital    : {initial_capital:,.0f} VND")
    print(f"   • Net Ending Capital : {ending_capital:,.0f} VND")
    print(f"   • Net Profit         : {net_profit:,.0f} VND")
    print(f"   • Total Return       : {total_return:.2%}")
    print(f"   • CAGR               : {cagr:.2%} / year")
    print("-" * 50)
    print(f"📉 RISK METRICS")
    print(f"   • Sharpe Ratio       : {sharpe_ratio:.2f}")
    print(f"   • Sortino Ratio      : {sortino_ratio:.2f}")
    print(f"   • Annual Volatility  : {volatility:.2%}")
    print(f"   • Max Drawdown       : {max_drawdown:.2%} (Bottom: {max_dd_date.date()})")
    print("-" * 50)
    print(f"🎲 TRADE STATISTICS (DAILY)")
    print(f"   • Winning Days       : {wins}")
    print(f"   • Losing Days        : {losses}")
    print(f"   • Win Rate           : {win_rate:.2%}")
    print("="*50 + "\n")

def plot_allocation_history(df_weights):
    """Plots the historical asset allocation (Stacked Area Chart)."""
    if df_weights.empty: return
    
    # Take Top 7 tickers with highest average weight
    top_tickers = df_weights.mean().sort_values(ascending=False).head(7).index
    plot_data = df_weights[top_tickers]
    plot_data['Others'] = df_weights.drop(columns=top_tickers).sum(axis=1)

    plt.figure(figsize=(12, 6))
    plt.stackplot(plot_data.index, plot_data.T, labels=plot_data.columns, alpha=0.8)
    plt.title('Portfolio Allocation History')
    plt.xlabel('Date')
    plt.ylabel('Weight (%)')
    plt.legend(loc='upper left')
    plt.tight_layout()
    plt.savefig('portfolio_allocation.png')
    print("   📷 Saved allocation chart: portfolio_allocation.png")

# ==============================================================================
# MAIN EXECUTION FUNCTION
# ==============================================================================
def run_pipeline_portfolio_construction(rebalance_freq='M', initial_capital=1_000_000_000):
    print("\n" + "="*60)
    print("🚀 STARTING PORTFOLIO CONSTRUCTION PIPELINE (MULTI-STRATEGY)")
    print("="*60)

    # --- STEP 1: ETL ---
    print("\n[1/6] 📥 Loading & Preparing Data...")
    df = load_local_data()
    if df is None: df = download_data(TICKERS_70, START_DATE, END_DATE)
    
    print("   🧹 Cleaning Data...")
    df_clean = clean_missing_values(df)
    # Winsorize disabled as requested to avoid artifacts with split-adjusted data
    # df_clean = clean_outliers_winsorize(df_clean) 

    # --- STEP 2: FEATURES & RISK ---
    print("\n[2/6] ⚙️ Generating Features & Strategy Signals...")
    # Call new Features function (MeanRev + Ichimoku + Sniper)
    df_features = full_generate_features(df_clean) 
    
    # Call Risk function
    df_risk = full_generate_risk_metrics(df_features)
    
    # Call new Strategy function (Scoring)
    df_final = full_generate_strategy_signal(df_risk)
    
    # --- STEP 3: PREPARE BACKTEST ---
    print(f"\n[3/6] 🔄 Initializing Backtest (Freq: {rebalance_freq})...")
    unique_dates = df_final.index.get_level_values(0).unique().sort_values()
    rebalance_dates = pd.Series(unique_dates, index=unique_dates).resample(rebalance_freq).last().index
    
    # Warmup 1 year
    start_date_idx = unique_dates.searchsorted(unique_dates[0] + pd.Timedelta(days=365))
    if start_date_idx >= len(unique_dates): return
    start_backtest_date = unique_dates[start_date_idx]
    valid_rebalance_dates = [d for d in rebalance_dates if d >= start_backtest_date]

    # Optimizer Config
    optimizer = PortfolioOptimizer(risk_aversion=2.5, max_weight=0.2)
    
    portfolio_history = []
    current_cash = initial_capital
    current_holdings = {}
    prices_wide = df_final['Close'].unstack()

    # --- STEP 4: TIME LOOP ---
    idx = pd.IndexSlice
    for i, target_date in enumerate(valid_rebalance_dates):
        if i == 0: continue 
        
        # Handle weekends/holidays
        current_date = unique_dates[unique_dates.searchsorted(target_date) - 1] if target_date not in unique_dates else target_date
        print(f"   📅 Rebalancing: {target_date.date()} (Data used: {current_date.date()})", end='\r')
        
        try:
            latest_data = df_final.loc[idx[current_date, :], :].reset_index(level=0, drop=True)
            historical_wide = prices_wide.loc[:current_date]
            
            # Calculate Inputs
            cov_matrix = calculate_covariance_matrix(historical_wide)
            
            common_tickers = latest_data.index.intersection(cov_matrix.index)
            if len(common_tickers) == 0: continue

            latest_data_valid = latest_data.loc[common_tickers]
            cov_matrix_valid = cov_matrix.loc[common_tickers, common_tickers]
            
            # Calculate Expected Return (Based on Ensemble Signal)
            # mu = Signal * Volatility
            mu = latest_data_valid['Signal'] * latest_data_valid['Vol_Annual']
            mu = mu.fillna(0)
            
            # Run Optimizer
            target_weights = optimizer.optimize(mu, cov_matrix_valid)
            if target_weights is None: target_weights = pd.Series(0, index=common_tickers)

        except Exception as e:
            target_weights = pd.Series(0, index=common_tickers)

        # Execute Trades (Calculate NAV)
        current_prices = historical_wide.iloc[-1]
        portfolio_value = current_cash
        for ticker, shares in current_holdings.items():
            if ticker in current_prices:
                portfolio_value += shares * current_prices[ticker]
        
        # SAVE WEIGHTS HISTORY
        weight_dict = target_weights.to_dict()
        portfolio_history.append({
            'Date': target_date,
            'NAV': portfolio_value,
            'Weights': weight_dict
        })
        
        # Rebalance Holdings
        new_holdings = {}
        allocated_cash = 0
        for ticker, weight in target_weights.items():
            if weight > 0 and ticker in current_prices and current_prices[ticker] > 0:
                target_value = portfolio_value * weight
                shares = int(target_value / current_prices[ticker])
                if shares > 0:
                    new_holdings[ticker] = shares
                    allocated_cash += shares * current_prices[ticker]
        
        current_cash = portfolio_value - allocated_cash
        current_holdings = new_holdings

    print("\n   ✅ Backtest Complete.")

    # --- STEP 5: RESULTS & REPORTING ---
    print("\n[5/6] 📊 Aggregating Results...")
    if not portfolio_history: return

    # Result DataFrame
    df_result = pd.DataFrame(portfolio_history).set_index('Date')
    df_result['Return'] = df_result['NAV'].pct_change().fillna(0)
    
    # Weights DataFrame (Export for analysis)
    df_weights = pd.DataFrame([x['Weights'] for x in portfolio_history], index=[x['Date'] for x in portfolio_history])
    df_weights = df_weights.fillna(0)
    df_weights.to_csv('portfolio_allocations.csv')
    print("   💾 Saved weights file: portfolio_allocations.csv")

    # Plot NAV
    plt.figure(figsize=(12, 6))
    plt.plot(df_result.index, df_result['NAV'], label='Portfolio NAV', color='green')
    plt.title('Portfolio Net Asset Value (NAV)')
    plt.xlabel('Year')
    plt.ylabel('VND')
    plt.legend()
    plt.grid(True)
    plt.savefig('portfolio_performance.png')
    
    # Plot Allocation
    try:
        plot_allocation_history(df_weights)
    except: pass

    # --- PRINT INTERNAL REPORT (ENGLISH) ---
    print_internal_report(df_result, initial_capital)

# ==============================================================================
# RUN
# ==============================================================================
if __name__ == "__main__":
    run_pipeline_portfolio_construction(rebalance_freq='M')