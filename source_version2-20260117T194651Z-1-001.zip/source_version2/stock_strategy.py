import pandas as pd
import numpy as np 
from backtesting.lib import crossover
from backtesting import Strategy
from stock_features import *

# Bollinger_Band_Mean_Reversion 
def generate_bollinger_signal(df):
    df_out = df.copy()

    # Điều kiện vào lệnh
    df_out["Long_entry"]  = (df_out["Close"] < df_out["Lower"]) | ((df_out["Zscore"] < -2) & (df_out["PercentB"] < 0))
    df_out["Short_entry"] = (df_out["Close"] > df_out["Upper"]) | ((df_out["Zscore"] > 2) & (df_out["PercentB"] > 1))

    # Điều kiện thoát lệnh
    df_out["Long_exit"]  = df_out["Close"] > df_out["Middle"]
    df_out["Short_exit"] = df_out["Close"] < df_out["Middle"]

    # Tạo cột signal
    df_out["Signal"] = 0

    position = 0  # 1 = long, -1 = short, 0 = neutral
    signals = []

    for i in range(len(df_out)):
        if position == 0:
            if df_out["Long_entry"].iloc[i]:
                position = 1
            elif df_out["Short_entry"].iloc[i]:
                position = -1

        elif position == 1:
            if df_out["Long_exit"].iloc[i]:
                position = 0

        elif position == -1:
            if df_out["Short_exit"].iloc[i]:
                position = 0

        signals.append(position)

    df_out["Signal"] = signals
    return df_out

def full_generate_bollinger_signal(df):
    df_processed = df.groupby("Ticker", group_keys=False).apply(generate_bollinger_signal)
    return df_processed

class SniperStrategy(Strategy):
    # Tham số tối ưu
    n_mid = 50
    sl_multiplier = 2.5
    risk_pct = 0.02

    def init(self):
        # 1. Khai báo chỉ báo
        self.sma_200 = self.I(get_sma, self.data.Close, 200)
        self.sma_50 = self.I(get_sma, self.data.Close, self.n_mid)
        self.vwma_50 = self.I(get_vwma, self.data.Close, self.data.Volume, self.n_mid)

        # Gọi GARCH đã tính sẵn
        self.garch = self.I(lambda x: x, self.data.Garch, name='Garch_Vol')

    # --- HÀM PHỤ TRỢ: TÍNH SIZE VÀ STOPLOSS (Dùng chung cho cả Long và Short) ---
    def calculate_risk(self, price, is_short=False):
        vol = self.garch[-1]

        # Khoảng cách Stoploss (Dựa trên GARCH)
        # Tối thiểu 1% để tránh bị quét khi GARCH quá thấp
        dist = max(price * vol * self.sl_multiplier, price * 0.01)

        # Tính khối lượng vào lệnh (Position Sizing)
        risk_amt = self.equity * self.risk_pct
        size = int(risk_amt / dist)

        # Xác định giá Stoploss dựa trên chiều đánh
        if is_short:
            sl_price = price + dist  # Short: SL nằm TRÊN giá
        else:
            sl_price = price - dist  # Long: SL nằm DƯỚI giá

        return size, sl_price

    def next(self):
        price = self.data.Close[-1]

        # ---------------------------------------------------
        # TRƯỜNG HỢP 1: CHƯA CÓ LỆNH (TÌM ĐIỂM VÀO)
        # ---------------------------------------------------
        if not self.position:

            # --- A. TÍN HIỆU LONG (MUA) ---
            # Xu hướng Tăng (Giá > SMA200) & VWMA cắt LÊN SMA50
            if price > self.sma_200[-1] and crossover(self.vwma_50, self.sma_50):

                # Gọi hàm tính toán rủi ro (is_short=False)
                size, sl_price = self.calculate_risk(price, is_short=False)

                if self.equity >= size * price and size > 0:
                    self.buy(size=size, sl=sl_price)

            # --- B. TÍN HIỆU SHORT (BÁN KHỐNG) ---
            # Xu hướng Giảm (Giá < SMA200) & VWMA cắt XUỐNG SMA50
            # Lưu ý: crossover(A, B) là A cắt lên B.
            # Muốn VWMA cắt xuống SMA thì viết ngược lại: crossover(SMA, VWMA)
            elif price < self.sma_200[-1] and crossover(self.sma_50, self.vwma_50):

                # Gọi hàm tính toán rủi ro (is_short=True)
                size, sl_price = self.calculate_risk(price, is_short=True)

                if self.equity >= size * price and size > 0:
                    self.sell(size=size, sl=sl_price)

        # ---------------------------------------------------
        # TRƯỜNG HỢP 2: ĐANG CÓ LỆNH (TÌM ĐIỂM RA)
        # ---------------------------------------------------
        else:
            # Nếu đang giữ vị thế LONG
            if self.position.is_long:
                # Thoát khi VWMA cắt xuống SMA50 (Mất đà tăng)
                if crossover(self.sma_50, self.vwma_50):
                    self.position.close()

            # Nếu đang giữ vị thế SHORT
            elif self.position.is_short:
                # Thoát khi VWMA cắt lên SMA50 (Có đà hồi phục)
                if crossover(self.vwma_50, self.sma_50):
                    self.position.close()

''' strategy cần sửa lại hoặc khúc này t vẫn chưa ngẫm được logic của m :<'''